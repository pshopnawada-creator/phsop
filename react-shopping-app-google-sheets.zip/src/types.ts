export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  discountPrice?: number;
  description: string;
  unit: string; // kg, dozen, liter, pcs, etc.
  images: string[];
}

export interface User {
  id: string;
  name: string;
  phone: string;
  avatar?: string;
  address?: string;
  area?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  items: CartItem[];
  totalPrice: number;
  address: string;
  area: string;
  donation: number;
  deliveryFee: number;
  status: 'Pending' | 'Confirmed' | 'Delivered' | 'Cancelled';
  date: string;
  time: string;
}

export interface AppSettings {
  appName: string;
  theme: 'light' | 'dark';
  areas: string[];
  helplinePhone: string;
  helplineEmail: string;
}

import { Product, Order, User, AppSettings } from '../types';

// URLs provided by the user
const SHEET_URLS = {
  login: 'https://script.google.com/macros/s/AKfycbwKOj_WbVDPJaJn_cKSeTV6__Wa9IDmGnn_qCW1Bl2drapM3euMMg8L_PLTB3fyj-vVTQ/exec',
  products: 'https://script.google.com/macros/s/AKfycbwTfS5UKZpo2VulBCGMLWrt81K7y7rToeF6qsV5EAl8prfSPBACrW8I7TaVTsxrYrhtug/exec',
  orders: 'https://script.google.com/macros/s/AKfycbxEXmetrdB6-MIMFI4bbmldrhHJKnsNXrcMhMrwLaImw27nM4LuKrZnZbsu8V-v3dJk/exec',
  settings: 'https://script.google.com/macros/s/AKfycbzfdVWuSSoIL45e-dz8uC-Lg_7muCZJudmWSMEkQsPHFYgVAkuhtNyP8m1z52VmneHy/exec',
};

// Seed default dynamic data if local storage is empty
const defaultProducts: Product[] = [
  {
    id: 'p1',
    name: 'Fresh Red Apples (Premium)',
    category: 'Fruits',
    price: 180,
    discountPrice: 150,
    description: 'Juicy, sweet red apples imported fresh. Best for breakfast and smoothies.',
    unit: 'kg',
    images: [
      'https://images.unsplash.com/photo-1560807707-8cc77767d783?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1570913149827-d2ac84ab3f9a?auto=format&fit=crop&w=600&q=80'
    ]
  },
  {
    id: 'p2',
    name: 'Organic Bananas',
    category: 'Fruits',
    price: 60,
    discountPrice: 48,
    description: 'Healthy and ripe organic bananas. Full of potassium and natural energy.',
    unit: 'dozen',
    images: [
      'https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1481349518771-20055b2a7b24?auto=format&fit=crop&w=600&q=80'
    ]
  },
  {
    id: 'p3',
    name: 'Pure Mustard Oil',
    category: 'Groceries',
    price: 185,
    discountPrice: 172,
    description: 'Cold-pressed authentic mustard oil. Ideal for aromatic Indian cooking.',
    unit: 'liter',
    images: [
      'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1620706857370-e1b977f72226?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?auto=format&fit=crop&w=600&q=80'
    ]
  },
  {
    id: 'p4',
    name: 'Men\'s Cotton T-Shirt',
    category: 'Clothes',
    price: 499,
    discountPrice: 349,
    description: 'Premium quality 100% pure cotton classic fit casual t-shirt.',
    unit: 'pcs',
    images: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=600&q=80'
    ]
  },
  {
    id: 'p5',
    name: 'Fresh Green Broccoli',
    category: 'Vegetables',
    price: 120,
    discountPrice: 99,
    description: 'Rich in nutrients, handpicked garden fresh green broccoli.',
    unit: 'kg',
    images: [
      'https://images.unsplash.com/photo-1453227588063-bb302b62f50b?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1515516089376-88db1e2689c1?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=600&q=80'
    ]
  },
];

const defaultSettings: AppSettings = {
  appName: 'pshop',
  theme: 'light',
  areas: [
    'Nawada Bazaar',
    'Main Market',
    'Old Bus Stand',
    'Gola Road',
    'Prasad Bigaha',
    'New Area',
    'Gondapur',
    'Station Road'
  ],
  helplinePhone: '8298799319',
  helplineEmail: 'pshopnawda@gmail.com',
};

// Helper to interact with local storage
const loadStorage = <T>(key: string, defaultValue: T): T => {
  const stored = localStorage.getItem(key);
  if (!stored) {
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
  }
  try {
    return JSON.parse(stored) as T;
  } catch {
    return defaultValue;
  }
};

const saveStorage = <T>(key: string, data: T) => {
  localStorage.setItem(key, JSON.stringify(data));
};

// Storage keys
const STORAGE_KEYS = {
  users: 'pshop_users',
  products: 'pshop_products',
  orders: 'pshop_orders',
  settings: 'pshop_settings',
  currentUser: 'pshop_currentUser',
};

// API Methods
export const api = {
  // Connection Test (satisfying internet check)
  isOnline: (): boolean => {
    return window.navigator.onLine;
  },

  // 1. LOGIN SHEET OPERATIONS
  logLogin: async (name: string, phone: string, isGoogleLogin = false): Promise<User> => {
    const userId = 'u-' + Math.random().toString(36).substring(2, 9);
    const date = new Date().toLocaleDateString();
    const time = new Date().toLocaleTimeString();

    const newUser: User = { id: userId, name, phone };

    // Update local users list
    const users = loadStorage<User[]>(STORAGE_KEYS.users, []);
    users.push(newUser);
    saveStorage(STORAGE_KEYS.users, users);
    saveStorage(STORAGE_KEYS.currentUser, newUser);

    // Fetch Google Sheet with fallback
    try {
      await fetch(SHEET_URLS.login, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, name, phone, date, time, method: isGoogleLogin ? 'Google' : 'Phone' })
      });
    } catch (error) {
      console.warn('Google Sheet logLogin warning (handled with local data):', error);
    }

    return newUser;
  },

  getCurrentUser: (): User | null => {
    return loadStorage<User | null>(STORAGE_KEYS.currentUser, null);
  },

  clearCurrentUser: () => {
    localStorage.removeItem(STORAGE_KEYS.currentUser);
  },

  saveCurrentUser: (user: User) => {
    saveStorage(STORAGE_KEYS.currentUser, user);
    const users = loadStorage<User[]>(STORAGE_KEYS.users, []);
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = user;
    } else {
      users.push(user);
    }
    saveStorage(STORAGE_KEYS.users, users);
  },

  getLogins: (): User[] => {
    return loadStorage<User[]>(STORAGE_KEYS.users, []);
  },

  // 2. PRODUCT SHEET OPERATIONS
  getProducts: async (): Promise<Product[]> => {
    // 1st: try fetching from google sheet just in case (e.g. GET)
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 2000); // 2 sec timeout for quickness
      const response = await fetch(SHEET_URLS.products, { signal: controller.signal });
      clearTimeout(id);
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data)) {
          saveStorage(STORAGE_KEYS.products, data);
          return data;
        }
      }
    } catch {
      // Fallback to local storage or defaults
    }
    return loadStorage<Product[]>(STORAGE_KEYS.products, defaultProducts);
  },

  saveProduct: async (product: Product): Promise<void> => {
    const products = loadStorage<Product[]>(STORAGE_KEYS.products, defaultProducts);
    const index = products.findIndex(p => p.id === product.id);
    if (index !== -1) {
      products[index] = product;
    } else {
      products.push(product);
    }
    saveStorage(STORAGE_KEYS.products, products);

    try {
      await fetch(SHEET_URLS.products, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'createOrUpdate', ...product })
      });
    } catch (error) {
      console.warn('Google Sheet saveProduct warning:', error);
    }
  },

  deleteProduct: async (id: string): Promise<void> => {
    let products = loadStorage<Product[]>(STORAGE_KEYS.products, defaultProducts);
    products = products.filter(p => p.id !== id);
    saveStorage(STORAGE_KEYS.products, products);

    try {
      await fetch(SHEET_URLS.products, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id })
      });
    } catch (error) {
      console.warn('Google Sheet deleteProduct warning:', error);
    }
  },

  // 3. ORDER SHEET OPERATIONS
  createOrder: async (order: Order): Promise<void> => {
    const orders = loadStorage<Order[]>(STORAGE_KEYS.orders, []);
    orders.push(order);
    saveStorage(STORAGE_KEYS.orders, orders);

    try {
      await fetch(SHEET_URLS.orders, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...order })
      });
    } catch (error) {
      console.warn('Google Sheet createOrder warning:', error);
    }
  },

  getOrders: (): Order[] => {
    return loadStorage<Order[]>(STORAGE_KEYS.orders, []);
  },

  updateOrderStatus: async (orderId: string, status: Order['status']): Promise<void> => {
    const orders = loadStorage<Order[]>(STORAGE_KEYS.orders, []);
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.status = status;
      saveStorage(STORAGE_KEYS.orders, orders);

      try {
        await fetch(SHEET_URLS.orders, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'updateStatus', orderId, status })
        });
      } catch (error) {
        console.warn('Google Sheet updateOrderStatus warning:', error);
      }
    }
  },

  // 4. SETTINGS SHEET OPERATIONS
  getSettings: async (): Promise<AppSettings> => {
    try {
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(SHEET_URLS.settings, { signal: controller.signal });
      clearTimeout(id);
      if (res.ok) {
        const data = await res.json();
        if (data && data.appName) {
          saveStorage(STORAGE_KEYS.settings, data);
          return data;
        }
      }
    } catch {
      // Fallback
    }
    return loadStorage<AppSettings>(STORAGE_KEYS.settings, defaultSettings);
  },

  saveSettings: async (settings: AppSettings): Promise<void> => {
    saveStorage(STORAGE_KEYS.settings, settings);
    try {
      await fetch(SHEET_URLS.settings, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'saveSettings', ...settings })
      });
    } catch (error) {
      console.warn('Google Sheet saveSettings warning:', error);
    }
  }
};

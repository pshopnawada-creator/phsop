import React from 'react';
import { translations, Language } from '../services/i18n';
import { User } from '../types';
import { Search, ShoppingCart, Globe, Sparkles } from 'lucide-react';

interface NavbarProps {
  user: User | null;
  lang: Language;
  onChangeLang: (l: Language) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  cartCount: number;
  onViewCart: () => void;
  appName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  lang,
  onChangeLang,
  searchQuery,
  onSearchChange,
  cartCount,
  onViewCart,
  appName
}) => {
  const t = translations[lang];

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm transition duration-150">
      <div className="max-w-6xl mx-auto px-4">
        {/* Upper Header Row */}
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-extrabold text-lg shadow-sm">
              P
            </div>
            <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              {appName}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Display logged in name or guest */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-gray-50 dark:bg-gray-700/60 rounded-full border border-gray-100 dark:border-gray-600 text-xs text-gray-600 dark:text-gray-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span className="font-semibold">{user ? user.name : (lang === 'hi' ? 'अतिथि' : 'Guest')}</span>
            </div>

            {/* Language picker */}
            <div className="flex items-center gap-1 border border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 px-2.5 py-1.5 rounded-full shadow-sm">
              <Globe className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
              <select
                value={lang}
                onChange={(e) => onChangeLang(e.target.value as Language)}
                className="bg-transparent text-xs font-bold outline-none text-gray-700 dark:text-gray-200"
              >
                <option value="en">EN</option>
                <option value="hi">हिन्दी</option>
                <option value="bho">भोज</option>
              </select>
            </div>

            {/* View Cart Button */}
            <button
              onClick={onViewCart}
              className="relative p-2 rounded-full border border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:border-blue-200 transition duration-150"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700 dark:text-gray-300" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-red-500 text-[10px] font-black text-white ring-2 ring-white dark:ring-gray-800">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Lower Header Search Row */}
        <div className="py-2.5 flex items-center justify-between gap-3">
          <div className="relative flex-grow flex items-center bg-gray-100/90 dark:bg-gray-900 border border-gray-100 dark:border-gray-700 rounded-2xl focus-within:border-blue-400 focus-within:bg-white focus-within:ring-2 focus-within:ring-blue-100 dark:focus-within:ring-blue-900/40 px-3.5 py-1.5 transition duration-150">
            <Search className="w-4 h-4 text-gray-400 mr-2 flex-shrink-0" />
            <input
              type="text"
              placeholder={t.search}
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full text-sm outline-none bg-transparent text-gray-800 dark:text-gray-100"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { User, AppSettings } from '../types';
import { Language, translations } from '../services/i18n';
import {
  UserCircle,
  MapPin,
  Settings,
  Store,
  Phone,
  Mail,
  LogOut,
  Moon,
  Sun,
  Edit3,
  Camera
} from 'lucide-react';

interface AccountViewProps {
  user: User | null;
  onUpdateUser: (u: User) => void;
  onLogout: () => void;
  lang: Language;
  settings: AppSettings;
  onUpdateSettings: (s: AppSettings) => void;
  areas: string[];
}

export const AccountView: React.FC<AccountViewProps> = ({
  user,
  onUpdateUser,
  onLogout,
  lang,
  settings,
  onUpdateSettings,
  areas,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'address' | 'settings' | 'sell' | null>(null);

  // Editing profile inputs
  const [editName, setEditName] = useState(user?.name || '');
  const [editPhone, setEditPhone] = useState(user?.phone || '');
  const [editAvatar, setEditAvatar] = useState(user?.avatar || '');

  // Address editing inputs
  const [editAddress, setEditAddress] = useState(user?.address || '');
  const [editArea, setEditArea] = useState(user?.area || areas[0] || '');

  // App Settings customization
  const [customAppName, setCustomAppName] = useState(settings.appName || 'pshop');

  // Sell on pshop inputs
  const [sellShopName, setSellShopName] = useState('');
  const [sellProductDetails, setSellProductDetails] = useState('');

  const t = translations[lang];

  // Image Upload handler for Profile Avatar
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = () => {
    if (!editName.trim() || !editPhone.trim()) return;
    if (user) {
      const updated: User = {
        ...user,
        name: editName,
        phone: editPhone,
        avatar: editAvatar,
      };
      onUpdateUser(updated);
      alert(lang === 'hi' ? 'प्रोफ़ाइल सफलतापूर्वक अपडेट हो गई!' : 'Profile updated successfully!');
    }
  };

  const handleSaveAddress = () => {
    if (!editAddress.trim()) return;
    if (user) {
      const updated: User = {
        ...user,
        address: editAddress,
        area: editArea,
      };
      onUpdateUser(updated);
      alert(lang === 'hi' ? 'पता सफलतापूर्वक सहेजा गया!' : 'Address saved successfully!');
    }
  };

  const handleSaveSettings = () => {
    if (!customAppName.trim()) return;
    const updatedSettings: AppSettings = {
      ...settings,
      appName: customAppName,
    };
    onUpdateSettings(updatedSettings);
    alert(lang === 'hi' ? 'सेटिंग्स अपडेट हो गई हैं!' : 'Settings updated successfully!');
  };

  const toggleTheme = () => {
    const nextTheme = settings.theme === 'dark' ? 'light' : 'dark';
    onUpdateSettings({ ...settings, theme: nextTheme });
  };

  const handleSendVendorMail = () => {
    if (!sellShopName.trim() || !sellProductDetails.trim()) {
      alert(lang === 'hi' ? 'कृपया सभी विक्रेता जानकारी भरें' : 'Please fill all vendor info');
      return;
    }
    const mailToLink = `mailto:${settings.helplineEmail}?subject=Vendor Registration: ${sellShopName}&body=Hi pshop team,%0D%0A%0D%0AI want to sell items on pshop.%0D%0AShop Details: ${sellShopName}%0D%0AProducts: ${sellProductDetails}%0D%0AContact Phone: ${user?.phone || 'Not Logged In'}`;
    window.location.href = mailToLink;
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 pb-20">
      <div className="flex flex-col items-center mb-6">
        {/* Profile Avatar Frame */}
        <div className="relative w-20 h-20 rounded-3xl bg-gray-100 dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 overflow-hidden shadow-md flex items-center justify-center select-none group">
          {editAvatar ? (
            <img src={editAvatar} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <UserCircle className="w-10 h-10 text-gray-400" />
          )}
          <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition duration-150 cursor-pointer">
            <Camera className="w-5 h-5 text-white" />
            <input
              type="file"
              accept="image/*"
              onChange={handleAvatarUpload}
              className="hidden"
            />
          </label>
        </div>

        <h2 className="text-lg font-extrabold text-gray-900 dark:text-white mt-3 leading-tight select-none">
          {user ? user.name : (lang === 'hi' ? 'अतिथि (Guest)' : 'Guest')}
        </h2>
        <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 select-none">
          {user ? user.phone : 'Browse mode only'}
        </span>
      </div>

      {!user ? (
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm text-center mb-5">
          <p className="text-xs font-bold text-gray-600 dark:text-gray-400 mb-4 select-none">
            {t.login_req}
          </p>
          <button
            onClick={onLogout}
            className="w-full bg-blue-600 text-white py-3 rounded-2xl font-black text-xs cursor-pointer hover:bg-blue-700 transition"
          >
            {t.login}
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {/* Main profile section editing */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 shadow-sm">
            <button
              onClick={() => setActiveTab(activeTab === 'profile' ? null : 'profile')}
              className="w-full flex items-center justify-between text-left cursor-pointer select-none"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center shadow-sm">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-gray-800 dark:text-white">
                    {lang === 'hi' ? 'प्रोफ़ाइल संपादित करें' : 'Edit Profile'}
                  </h3>
                  <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    Change name, photo and mobile
                  </p>
                </div>
              </div>
              <span className="text-xs text-gray-400">{activeTab === 'profile' ? '▲' : '▼'}</span>
            </button>

            {activeTab === 'profile' && (
              <div className="mt-4 pt-4 border-t border-gray-50 dark:border-gray-700 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {lang === 'hi' ? 'पूरा नाम' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {lang === 'hi' ? 'मोबाइल नंबर' : 'Phone Number'}
                  </label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value.replace(/\D/g, ''))}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none"
                  />
                </div>
                <button
                  onClick={handleSaveProfile}
                  className="w-full bg-blue-600 text-white py-3 rounded-2xl font-black text-xs cursor-pointer hover:bg-blue-700 transition"
                >
                  {lang === 'hi' ? 'प्रोफ़ाइल सहेजें' : 'Save Profile'}
                </button>
              </div>
            )}
          </div>

          {/* Address Management Tab */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 shadow-sm">
            <button
              onClick={() => setActiveTab(activeTab === 'address' ? null : 'address')}
              className="w-full flex items-center justify-between text-left cursor-pointer select-none"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center shadow-sm">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-gray-800 dark:text-white">
                    {t.address}
                  </h3>
                  <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    Nawada area & landmark address
                  </p>
                </div>
              </div>
              <span className="text-xs text-gray-400">{activeTab === 'address' ? '▲' : '▼'}</span>
            </button>

            {activeTab === 'address' && (
              <div className="mt-4 pt-4 border-t border-gray-50 dark:border-gray-700 space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {t.area}
                  </label>
                  <select
                    value={editArea}
                    onChange={(e) => setEditArea(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-3 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                  >
                    {areas.map((ar) => (
                      <option key={ar} value={ar}>
                        {ar}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {t.street_address}
                  </label>
                  <textarea
                    rows={2}
                    value={editAddress}
                    onChange={(e) => setEditAddress(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-3 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                  />
                </div>
                <button
                  onClick={handleSaveAddress}
                  className="w-full bg-blue-600 text-white py-3 rounded-2xl font-black text-xs cursor-pointer hover:bg-blue-700 transition"
                >
                  {lang === 'hi' ? 'पता सहेजें' : 'Save Address'}
                </button>
              </div>
            )}
          </div>

          {/* App Settings Tab */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 shadow-sm">
            <button
              onClick={() => setActiveTab(activeTab === 'settings' ? null : 'settings')}
              className="w-full flex items-center justify-between text-left cursor-pointer select-none"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 flex items-center justify-center shadow-sm">
                  <Settings className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-gray-800 dark:text-white">
                    {t.settings}
                  </h3>
                  <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    Theme mode and app customization
                  </p>
                </div>
              </div>
              <span className="text-xs text-gray-400">{activeTab === 'settings' ? '▲' : '▼'}</span>
            </button>

            {activeTab === 'settings' && (
              <div className="mt-4 pt-4 border-t border-gray-50 dark:border-gray-700 space-y-4">
                {/* Dark mode Toggle */}
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-gray-800 dark:text-gray-200">
                      {t.dark_mode}
                    </h5>
                    <p className="text-[10px] text-gray-400">
                      Toggle dark interface theme
                    </p>
                  </div>
                  <button
                    onClick={toggleTheme}
                    className="p-2.5 rounded-2xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-700 dark:text-gray-300 transition"
                  >
                    {settings.theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </button>
                </div>

                {/* Customize Name */}
                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {lang === 'hi' ? 'एप्लिकेशन का नाम' : 'App Title'}
                  </label>
                  <input
                    type="text"
                    value={customAppName}
                    onChange={(e) => setCustomAppName(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none focus:border-blue-400"
                  />
                </div>
                <button
                  onClick={handleSaveSettings}
                  className="w-full bg-blue-600 text-white py-3 rounded-2xl font-black text-xs cursor-pointer hover:bg-blue-700 transition"
                >
                  {lang === 'hi' ? 'सेटिंग्स सहेजें' : 'Save Settings'}
                </button>
              </div>
            )}
          </div>

          {/* Sell on pshop Tab */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 shadow-sm">
            <button
              onClick={() => setActiveTab(activeTab === 'sell' ? null : 'sell')}
              className="w-full flex items-center justify-between text-left cursor-pointer select-none"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 flex items-center justify-center shadow-sm">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-gray-800 dark:text-white">
                    {t.sell}
                  </h3>
                  <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    Add items & products to sell here
                  </p>
                </div>
              </div>
              <span className="text-xs text-gray-400">{activeTab === 'sell' ? '▲' : '▼'}</span>
            </button>

            {activeTab === 'sell' && (
              <div className="mt-4 pt-4 border-t border-gray-50 dark:border-gray-700 space-y-4 animate-fade-in">
                <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed bg-amber-50/20 dark:bg-amber-950/20 p-3 rounded-2xl border border-amber-100/40 dark:border-amber-900/20 select-none">
                  {lang === 'hi'
                    ? 'pshop पर अपना व्यवसाय शुरू करें! नीचे फ़ॉर्म भरें और अपनी दुकान का विवरण सबमिट करें ताकि हमारी टीम आपको विक्रेता पैनल का उपयोग करने के लिए अधिकृत कर सके।'
                    : 'Start your retail store with pshop! Fill out the info below to register your business and begin receiving online sales.'}
                </p>

                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {lang === 'hi' ? 'दुकान का नाम' : 'Business/Shop Name'}
                  </label>
                  <input
                    type="text"
                    value={sellShopName}
                    onChange={(e) => setSellShopName(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-500 dark:text-gray-400">
                    {lang === 'hi' ? 'उत्पादों का प्रकार / विवरण' : 'Category of items to Sell'}
                  </label>
                  <textarea
                    rows={2}
                    value={sellProductDetails}
                    onChange={(e) => setSellProductDetails(e.target.value)}
                    className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none"
                  />
                </div>

                <button
                  onClick={handleSendVendorMail}
                  className="w-full bg-blue-600 text-white py-3 rounded-2xl font-black text-xs cursor-pointer hover:bg-blue-700 transition"
                >
                  {lang === 'hi' ? 'विक्रेता अनुरोध सबमिट करें' : 'Send Vendor Inquiry'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Support Helpline Panel */}
      <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm space-y-3.5 mt-5">
        <h3 className="font-extrabold text-sm text-gray-800 dark:text-white border-b border-gray-50 dark:border-gray-700 pb-2">
          {lang === 'hi' ? 'सहायता केंद्र' : 'Support Center'}
        </h3>
        <div className="flex flex-col gap-3">
          <a
            href={`tel:${settings.helplinePhone}`}
            className="flex items-center gap-3 bg-gray-50/50 dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-100 dark:border-gray-700 p-3 rounded-2xl cursor-pointer transition text-gray-800 dark:text-gray-200"
          >
            <div className="w-9 h-9 rounded-xl bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase block tracking-wider">
                {t.help_no}
              </span>
              <span className="text-sm font-extrabold">{settings.helplinePhone}</span>
            </div>
          </a>

          <a
            href={`mailto:${settings.helplineEmail}`}
            className="flex items-center gap-3 bg-gray-50/50 dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-100 dark:border-gray-700 p-3 rounded-2xl cursor-pointer transition text-gray-800 dark:text-gray-200"
          >
            <div className="w-9 h-9 rounded-xl bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase block tracking-wider">
                {t.email}
              </span>
              <span className="text-sm font-extrabold">{settings.helplineEmail}</span>
            </div>
          </a>
        </div>
      </div>

      {/* Logout button */}
      <button
        onClick={onLogout}
        className="w-full mt-6 bg-red-50/80 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 border border-red-100 dark:border-red-900/40 text-red-600 dark:text-red-300 py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 cursor-pointer shadow-sm hover:shadow transition"
      >
        <LogOut className="w-4 h-4" />
        {t.logout}
      </button>
    </div>
  );
};

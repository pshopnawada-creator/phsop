import React, { useState } from 'react';
import { api } from '../services/api';
import { translations, Language } from '../services/i18n';
import { Phone, User, Globe, ShieldCheck } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (name: string, phone: string, isGoogleLogin?: boolean) => void;
  onSkip: () => void;
  lang: Language;
  onChangeLang: (l: Language) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onSkip, lang, onChangeLang }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  const t = translations[lang];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setError(lang === 'hi' ? 'कृपया सभी फ़ील्ड भरें।' : 'Please fill all fields.');
      return;
    }
    if (phone.length < 10) {
      setError(lang === 'hi' ? 'कृपया एक वैध 10-अंकों का नंबर दर्ज करें।' : 'Please enter a valid 10-digit number.');
      return;
    }
    setError('');
    const user = await api.logLogin(name, phone);
    onLogin(user.name, user.phone, false);
  };

  const handleGoogleLogin = async () => {
    // Premium Google login mockup
    const promptName = prompt(lang === 'hi' ? 'कृपया अपना गूगल नाम दर्ज करें' : 'Enter your Google account name:');
    const promptPhone = prompt(lang === 'hi' ? 'कृपया अपना फोन नंबर दर्ज करें' : 'Enter your phone number:');
    if (promptName && promptPhone && promptPhone.length >= 10) {
      const user = await api.logLogin(promptName, promptPhone, true);
      onLogin(user.name, user.phone, true);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 justify-center items-center px-4 py-8">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-3xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
        {/* Language selector in top corner */}
        <div className="flex justify-end p-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
          <div className="flex items-center gap-1.5 bg-white dark:bg-gray-800 px-3 py-1.5 rounded-full border border-gray-200 dark:border-gray-700 shadow-sm">
            <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <select
              value={lang}
              onChange={(e) => onChangeLang(e.target.value as Language)}
              className="bg-transparent text-sm font-semibold outline-none text-gray-700 dark:text-gray-200"
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी</option>
              <option value="bho">भोजपुरी</option>
            </select>
          </div>
        </div>

        <div className="p-6 sm:p-8 flex flex-col items-center">
          {/* Logo & Header */}
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-700 flex items-center justify-center text-white text-3xl font-black mb-3 shadow-lg shadow-indigo-200 dark:shadow-indigo-950">
            P
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white text-center flex items-center gap-2">
            <span>pshop</span>
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-6 max-w-[280px]">
            {t.welcome}
          </p>

          <form onSubmit={handleSubmit} className="w-full space-y-4">
            <div className="relative">
              <label className="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide ml-1">
                {lang === 'hi' ? 'पूरा नाम' : 'Your Name'}
              </label>
              <div className="mt-1 flex items-center bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 dark:focus-within:ring-blue-900 px-3 transition duration-200">
                <User className="w-5 h-5 text-gray-400 mr-2 flex-shrink-0" />
                <input
                  type="text"
                  placeholder={t.name_placeholder}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full py-3.5 outline-none text-gray-800 dark:text-gray-100 bg-transparent text-sm"
                />
              </div>
            </div>

            <div className="relative">
              <label className="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide ml-1">
                {lang === 'hi' ? 'मोबाइल नंबर' : 'Phone Number'}
              </label>
              <div className="mt-1 flex items-center bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-2xl focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 dark:focus-within:ring-blue-900 px-3 transition duration-200">
                <Phone className="w-5 h-5 text-gray-400 mr-2 flex-shrink-0" />
                <input
                  type="tel"
                  maxLength={10}
                  placeholder={t.phone_placeholder}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  className="w-full py-3.5 outline-none text-gray-800 dark:text-gray-100 bg-transparent text-sm"
                />
              </div>
            </div>

            {error && (
              <p className="text-xs font-semibold text-red-500 dark:text-red-400 mt-1 pl-1">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-4 rounded-2xl font-bold shadow-md hover:shadow-lg transition duration-200 text-sm tracking-wide mt-2 flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-5 h-5" />
              {t.submit}
            </button>
          </form>

          {/* Social login divider */}
          <div className="relative flex items-center py-4 w-full mt-2">
            <div className="flex-grow border-t border-gray-200 dark:border-gray-700"></div>
            <span className="flex-shrink mx-4 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">OR</span>
            <div className="flex-grow border-t border-gray-200 dark:border-gray-700"></div>
          </div>

          <button
            onClick={handleGoogleLogin}
            className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-200 py-3.5 rounded-2xl font-bold shadow-sm hover:shadow transition duration-200 text-sm tracking-wide flex items-center justify-center gap-2.5 mb-3"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            {t.google_login}
          </button>

          <button
            onClick={onSkip}
            className="w-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 py-3.5 rounded-2xl font-bold transition duration-200 text-sm tracking-wide flex items-center justify-center"
          >
            {t.skip}
          </button>
        </div>
      </div>
    </div>
  );
};

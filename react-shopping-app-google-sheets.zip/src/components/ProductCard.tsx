import React, { useState } from 'react';
import { Product } from '../types';
import { Language, translations } from '../services/i18n';
import { ShoppingCart, Flame, Sparkles, ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product, qty: number) => void;
  onBuyNow: (p: Product, qty: number) => void;
  lang: Language;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onBuyNow,
  lang,
}) => {
  const [selectedQty, setSelectedQty] = useState(1);
  const [isOpenDetails, setIsOpenDetails] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);

  const t = translations[lang];

  // Calculate discount percentage
  const discountPercent =
    product.discountPrice && product.price > 0
      ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
      : 0;

  const handleNextImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.images && product.images.length > 0) {
      setImgIdx((prev) => (prev + 1) % product.images.length);
    }
  };

  const handlePrevImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.images && product.images.length > 0) {
      setImgIdx((prev) => (prev - 1 + product.images.length) % product.images.length);
    }
  };

  const handleOpenDetails = () => setIsOpenDetails(true);
  const handleCloseDetails = () => setIsOpenDetails(false);

  return (
    <>
      {/* Product grid layout tile */}
      <div
        onClick={handleOpenDetails}
        className="group relative flex flex-col bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-2xl overflow-hidden cursor-pointer hover:shadow-lg transition duration-200"
      >
        {/* Banner discount tag */}
        {discountPercent > 0 && (
          <div className="absolute top-2.5 left-2.5 z-10 bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-0.5">
            <Flame className="w-3 h-3 animate-pulse" />
            {discountPercent}% OFF
          </div>
        )}

        {/* Thumbnail / cover photo */}
        <div className="aspect-square relative w-full overflow-hidden bg-gray-50 dark:bg-gray-900 select-none">
          <img
            src={product.images && product.images[0] ? product.images[0] : 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300 select-none pointer-events-none"
          />
        </div>

        {/* Details snippet */}
        <div className="p-3.5 flex flex-col flex-grow select-none">
          <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 tracking-wider uppercase mb-1">
            {product.category}
          </span>
          <h3 className="font-bold text-sm text-gray-800 dark:text-gray-100 line-clamp-2 leading-tight flex-grow mb-2">
            {product.name}
          </h3>

          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-base font-black text-blue-600 dark:text-blue-400">
              ₹{product.discountPrice ? product.discountPrice : product.price}
            </span>
            {product.discountPrice && (
              <span className="text-xs text-gray-400 dark:text-gray-500 font-semibold line-through">
                ₹{product.price}
              </span>
            )}
            <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
              / {product.unit}
            </span>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleOpenDetails();
            }}
            className="w-full border border-blue-100 hover:border-blue-300 bg-blue-50/50 hover:bg-blue-50 dark:bg-blue-900/10 dark:hover:bg-blue-900/30 text-blue-700 dark:text-blue-300 py-2 rounded-xl text-xs font-bold transition duration-150 flex items-center justify-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {lang === 'hi' ? 'विवरण देखें' : 'View Details'}
          </button>
        </div>
      </div>

      {/* Modern High-Quality Details & Purchase Overlay Modal */}
      {isOpenDetails && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-white dark:bg-gray-800 rounded-t-3xl sm:rounded-3xl max-h-[92vh] overflow-y-auto flex flex-col shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="sticky top-0 z-20 flex items-center justify-between p-4 bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
              <h4 className="font-extrabold text-gray-900 dark:text-white text-base">
                {product.name}
              </h4>
              <button
                onClick={handleCloseDetails}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 flex items-center justify-center text-gray-500 dark:text-gray-300 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Scrollable image slider or carousel (up to 3 photos) */}
            <div className="relative aspect-square w-full bg-gray-50 dark:bg-gray-900 select-none">
              <img
                src={product.images && product.images[imgIdx] ? product.images[imgIdx] : 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                alt={`${product.name} preview ${imgIdx}`}
                className="w-full h-full object-cover select-none pointer-events-none"
              />

              {/* Side slide buttons */}
              {product.images && product.images.length > 1 && (
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 px-3 flex justify-between">
                  <button
                    onClick={handlePrevImg}
                    className="w-9 h-9 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-full flex items-center justify-center shadow-md border border-gray-100 dark:border-gray-700 cursor-pointer text-gray-700 dark:text-gray-200"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleNextImg}
                    className="w-9 h-9 bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-full flex items-center justify-center shadow-md border border-gray-100 dark:border-gray-700 cursor-pointer text-gray-700 dark:text-gray-200"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              )}

              {/* Slider Dots */}
              {product.images && product.images.length > 1 && (
                <div className="absolute bottom-3 inset-x-0 flex justify-center gap-1.5">
                  {product.images.map((_, i) => (
                    <span
                      key={i}
                      className={`w-2.5 h-2 rounded-full border transition duration-150 ${
                        i === imgIdx
                          ? 'bg-blue-600 border-blue-600 w-5'
                          : 'bg-white/60 border-white/80'
                      }`}
                    ></span>
                  ))}
                </div>
              )}
            </div>

            {/* Product description, rates, details */}
            <div className="p-5 flex flex-col space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-xs bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 font-bold px-2.5 py-1 rounded-full uppercase">
                    {product.category}
                  </span>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-blue-600 dark:text-blue-400">
                    ₹{product.discountPrice ? product.discountPrice : product.price}
                  </span>
                  {product.discountPrice && (
                    <span className="text-sm text-gray-400 dark:text-gray-500 font-semibold line-through">
                      ₹{product.price}
                    </span>
                  )}
                  <span className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                    / {product.unit}
                  </span>
                </div>
              </div>

              <div>
                <h5 className="font-bold text-sm text-gray-700 dark:text-gray-200 mb-1">
                  {lang === 'hi' ? 'उत्पाद विवरण' : 'Description'}
                </h5>
                <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed bg-gray-50/50 dark:bg-gray-900/50 border border-gray-100/50 dark:border-gray-700 p-3 rounded-2xl">
                  {product.description || (lang === 'hi' ? 'कोई विवरण उपलब्ध नहीं है।' : 'No description provided.')}
                </p>
              </div>

              {/* Quantity selector */}
              <div className="flex items-center justify-between border border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900 p-3.5 rounded-2xl">
                <span className="font-bold text-xs text-gray-700 dark:text-gray-300">
                  {lang === 'hi' ? 'मात्रा (Quantity)' : 'Select Quantity'}:
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setSelectedQty((q) => Math.max(1, q - 1))}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 font-extrabold flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-100 cursor-pointer shadow-sm"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-extrabold text-sm text-gray-800 dark:text-gray-200">
                    {selectedQty}
                  </span>
                  <button
                    onClick={() => setSelectedQty((q) => q + 1)}
                    className="w-8 h-8 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 font-extrabold flex items-center justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-100 cursor-pointer shadow-sm"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add Cart & Buy Now Buttons */}
              <div className="grid grid-cols-2 gap-3.5 pt-2">
                <button
                  onClick={() => {
                    onAddToCart(product, selectedQty);
                    handleCloseDetails();
                  }}
                  className="w-full bg-white dark:bg-gray-800 border border-blue-600 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/40 py-3.5 rounded-2xl font-bold transition duration-200 text-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <ShoppingCart className="w-4 h-4" />
                  {t.add_to_cart}
                </button>
                <button
                  onClick={() => {
                    onBuyNow(product, selectedQty);
                    handleCloseDetails();
                  }}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3.5 rounded-2xl font-bold transition duration-200 text-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Check className="w-4 h-4" />
                  {t.buy_now}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
};

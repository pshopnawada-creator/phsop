import React, { useState } from 'react';
import { Product, Order, User, AppSettings } from '../types';
import { Language } from '../services/i18n';
import { api } from '../services/api';
import {
  Package,
  ShoppingBag,
  Users,
  Settings,
  Plus,
  Trash2,
  Edit,
  Save,
  CheckCircle,
  XCircle,
  Clock,
  Phone
} from 'lucide-react';

interface AdminViewProps {
  products: Product[];
  orders: Order[];
  users: User[];
  settings: AppSettings;
  onRefreshProducts: () => void;
  onRefreshOrders: () => void;
  onUpdateSettings: (s: AppSettings) => void;
  lang: Language;
}

export const AdminView: React.FC<AdminViewProps> = ({
  products,
  orders,
  users,
  settings,
  onRefreshProducts,
  onRefreshOrders,
  onUpdateSettings,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'products' | 'orders' | 'users' | 'settings'>('products');

  // Form states for creating/editing a product
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formPrice, setFormPrice] = useState<number>(0);
  const [formDiscountPrice, setFormDiscountPrice] = useState<number>(0);
  const [formDescription, setFormDescription] = useState('');
  const [formUnit, setFormUnit] = useState('kg');
  const [formImage1, setFormImage1] = useState('');
  const [formImage2, setFormImage2] = useState('');
  const [formImage3, setFormImage3] = useState('');

  // Setting dynamic areas form
  const [newArea, setNewArea] = useState('');

  const resetProductForm = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory('');
    setFormPrice(0);
    setFormDiscountPrice(0);
    setFormDescription('');
    setFormUnit('kg');
    setFormImage1('');
    setFormImage2('');
    setFormImage3('');
  };

  const startEditProduct = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name);
    setFormCategory(p.category);
    setFormPrice(p.price);
    setFormDiscountPrice(p.discountPrice || 0);
    setFormDescription(p.description);
    setFormUnit(p.unit);
    setFormImage1(p.images[0] || '');
    setFormImage2(p.images[1] || '');
    setFormImage3(p.images[2] || '');
  };

  const handleSaveProduct = async () => {
    if (!formName.trim() || !formCategory.trim() || formPrice <= 0) {
      alert('Please fill out name, category, and price!');
      return;
    }

    const imagesArray = [formImage1, formImage2, formImage3].filter(Boolean);
    if (imagesArray.length === 0) {
      imagesArray.push('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80');
    }

    const item: Product = {
      id: editingProduct ? editingProduct.id : 'p-' + Math.random().toString(36).substring(2, 9),
      name: formName,
      category: formCategory,
      price: formPrice,
      discountPrice: formDiscountPrice > 0 ? formDiscountPrice : undefined,
      description: formDescription,
      unit: formUnit,
      images: imagesArray,
    };

    await api.saveProduct(item);
    resetProductForm();
    onRefreshProducts();
    alert('Product updated successfully on Sheet 2 & Local!');
  };

  const handleDeleteProduct = async (id: string) => {
    if (confirm('Delete this product?')) {
      await api.deleteProduct(id);
      onRefreshProducts();
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
    await api.updateOrderStatus(orderId, status);
    onRefreshOrders();
  };

  const handleAddArea = () => {
    if (!newArea.trim()) return;
    if (settings.areas.includes(newArea)) return;
    const updated: AppSettings = {
      ...settings,
      areas: [...settings.areas, newArea.trim()],
    };
    onUpdateSettings(updated);
    setNewArea('');
  };

  const handleRemoveArea = (area: string) => {
    const updated: AppSettings = {
      ...settings,
      areas: settings.areas.filter((ar) => ar !== area),
    };
    onUpdateSettings(updated);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-24">
      <div className="flex items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-extrabold text-gray-900 dark:text-white leading-tight">
            Seller Dashboard
          </h2>
          <p className="text-xs text-gray-400 font-semibold select-none">
            Add & Edit Products (Sheet 2), View Logins (Sheet 1), Manage Orders (Sheet 3)
          </p>
        </div>
      </div>

      {/* Admin tabs switcher */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        <button
          onClick={() => setActiveSubTab('products')}
          className={`py-2 rounded-2xl text-xs font-black transition cursor-pointer select-none flex items-center justify-center gap-1.5 border shadow-sm ${
            activeSubTab === 'products'
              ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-100 dark:border-gray-700/80 hover:bg-gray-50'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          Items
        </button>
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`py-2 rounded-2xl text-xs font-black transition cursor-pointer select-none flex items-center justify-center gap-1.5 border shadow-sm ${
            activeSubTab === 'orders'
              ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-100 dark:border-gray-700/80 hover:bg-gray-50'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          Orders
        </button>
        <button
          onClick={() => setActiveSubTab('users')}
          className={`py-2 rounded-2xl text-xs font-black transition cursor-pointer select-none flex items-center justify-center gap-1.5 border shadow-sm ${
            activeSubTab === 'users'
              ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-100 dark:border-gray-700/80 hover:bg-gray-50'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Users
        </button>
        <button
          onClick={() => setActiveSubTab('settings')}
          className={`py-2 rounded-2xl text-xs font-black transition cursor-pointer select-none flex items-center justify-center gap-1.5 border shadow-sm ${
            activeSubTab === 'settings'
              ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-100 dark:border-gray-700/80 hover:bg-gray-50'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          Areas
        </button>
      </div>

      {/* --- SUB-VIEW 1: PRODUCTS / ITEMS MANAGER --- */}
      {activeSubTab === 'products' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-5 rounded-3xl shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-gray-800 dark:text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              {editingProduct ? 'Edit Selected Product' : 'Add New Product'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Product Name
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Fresh Red Apples"
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Product Category
                </label>
                <input
                  type="text"
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  placeholder="e.g. Fruits, Clothes, Vegetables"
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Base Price (₹)
                </label>
                <input
                  type="number"
                  value={formPrice || ''}
                  onChange={(e) => setFormPrice(Number(e.target.value))}
                  placeholder="e.g. 150"
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Discount Price (₹) (Optional)
                </label>
                <input
                  type="number"
                  value={formDiscountPrice || ''}
                  onChange={(e) => setFormDiscountPrice(Number(e.target.value))}
                  placeholder="e.g. 130"
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Unit Measurement
                </label>
                <input
                  type="text"
                  value={formUnit}
                  onChange={(e) => setFormUnit(e.target.value)}
                  placeholder="e.g. kg, dozen, liter, pcs"
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Description / Detail
              </label>
              <textarea
                rows={2}
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                placeholder="Product info, freshness detail..."
                className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
              />
            </div>

            {/* Support up to 3 image URLs */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Product Image URLs (Provide up to 3)
              </label>
              <input
                type="text"
                value={formImage1}
                onChange={(e) => setFormImage1(e.target.value)}
                placeholder="Image URL 1"
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400 mb-2"
              />
              <input
                type="text"
                value={formImage2}
                onChange={(e) => setFormImage2(e.target.value)}
                placeholder="Image URL 2 (Optional)"
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400 mb-2"
              />
              <input
                type="text"
                value={formImage3}
                onChange={(e) => setFormImage3(e.target.value)}
                placeholder="Image URL 3 (Optional)"
                className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleSaveProduct}
                className="flex-grow bg-blue-600 hover:bg-blue-700 text-white py-3.5 rounded-2xl font-black text-xs transition cursor-pointer select-none flex items-center justify-center gap-2 shadow-sm"
              >
                <Save className="w-4 h-4" />
                {editingProduct ? 'Save Changes' : 'Post Item'}
              </button>
              {editingProduct && (
                <button
                  onClick={resetProductForm}
                  className="px-4 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 py-3.5 rounded-2xl font-bold text-xs transition cursor-pointer select-none"
                >
                  Cancel
                </button>
              )}
            </div>
          </div>

          {/* Current Products listings */}
          <div className="space-y-3.5">
            <h3 className="font-extrabold text-sm text-gray-800 dark:text-white pl-1">
              Active Inventory Products
            </h3>

            {products.length === 0 ? (
              <p className="text-xs font-semibold text-gray-500 p-4">No active products added yet.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-3.5 rounded-2xl shadow-sm flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={p.images[0] || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                        alt={p.name}
                        className="w-14 h-14 object-cover rounded-xl border border-gray-100 select-none flex-shrink-0"
                      />
                      <div className="flex flex-col">
                        <span className="text-xs bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-300 px-2 py-0.5 rounded-full font-bold self-start mb-1 text-[10px] uppercase">
                          {p.category}
                        </span>
                        <h4 className="font-bold text-sm text-gray-800 dark:text-white leading-tight">
                          {p.name}
                        </h4>
                        <span className="text-xs font-black text-blue-600 mt-0.5">
                          ₹{p.discountPrice ? p.discountPrice : p.price}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <button
                        onClick={() => startEditProduct(p)}
                        className="p-2 bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl transition cursor-pointer"
                        title="Edit Item"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="p-2 bg-red-50 hover:bg-red-100 dark:bg-red-900/30 text-red-500 rounded-xl transition cursor-pointer"
                        title="Delete Item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- SUB-VIEW 2: ORDERS MANAGER --- */}
      {activeSubTab === 'orders' && (
        <div className="space-y-4">
          <h3 className="font-extrabold text-sm text-gray-800 dark:text-white pl-1">
            Customer Placed Orders
          </h3>

          {orders.length === 0 ? (
            <p className="text-xs font-semibold text-gray-500 p-4">No customer orders placed yet.</p>
          ) : (
            <div className="flex flex-col gap-4">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 sm:p-5 shadow-sm space-y-3.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2.5">
                    <div>
                      <span className="text-xs font-black text-blue-600 bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-full border border-blue-100 dark:border-blue-900/40">
                        {ord.id.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-400 ml-2 font-semibold select-none">
                        {ord.date} {ord.time}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {ord.status === 'Pending' && (
                        <span className="text-xs font-extrabold text-amber-500 bg-amber-50 dark:bg-amber-900/20 px-2.5 py-1 rounded-full flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Pending
                        </span>
                      )}
                      {ord.status === 'Confirmed' && (
                        <span className="text-xs font-extrabold text-blue-500 bg-blue-50 dark:bg-blue-900/20 px-2.5 py-1 rounded-full flex items-center gap-1">
                          <Package className="w-3 h-3" />
                          Confirmed
                        </span>
                      )}
                      {ord.status === 'Delivered' && (
                        <span className="text-xs font-extrabold text-green-500 bg-green-50 dark:bg-green-900/20 px-2.5 py-1 rounded-full flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          Delivered
                        </span>
                      )}
                      {ord.status === 'Cancelled' && (
                        <span className="text-xs font-extrabold text-red-500 bg-red-50 dark:bg-red-900/20 px-2.5 py-1 rounded-full flex items-center gap-1">
                          <XCircle className="w-3 h-3" />
                          Cancelled
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="border-t border-gray-50 dark:border-gray-700 pt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <h4 className="font-bold text-xs text-gray-500 uppercase tracking-wider select-none mb-1">
                        Customer
                      </h4>
                      <p className="text-sm font-black text-gray-800 dark:text-white">
                        {ord.userName}
                      </p>
                      <a
                        href={`tel:${ord.userPhone}`}
                        className="text-xs text-blue-600 hover:underline flex items-center gap-1 mt-1 cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        {ord.userPhone}
                      </a>
                    </div>

                    <div>
                      <h4 className="font-bold text-xs text-gray-500 uppercase tracking-wider select-none mb-1">
                        Delivery To
                      </h4>
                      <p className="text-sm font-bold text-gray-800 dark:text-white leading-snug">
                        {ord.address}
                      </p>
                      <span className="text-xs font-extrabold text-blue-500 dark:text-blue-400">
                        Area: {ord.area}
                      </span>
                    </div>
                  </div>

                  {/* Summary of Items */}
                  <div className="border-t border-gray-50 dark:border-gray-700 pt-3">
                    <h4 className="font-bold text-xs text-gray-500 uppercase tracking-wider select-none mb-1.5">
                      Items Breakdown
                    </h4>
                    <div className="space-y-1">
                      {ord.items.map((i, idx) => (
                        <div key={idx} className="flex justify-between text-xs text-gray-700 dark:text-gray-300 font-semibold">
                          <span>
                            {i.product.name} ({i.quantity} × ₹{i.product.discountPrice || i.product.price})
                          </span>
                          <span className="font-bold text-gray-800 dark:text-white">
                            ₹{(i.product.discountPrice || i.product.price) * i.quantity}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Complete footer status update */}
                  <div className="border-t border-gray-50 dark:border-gray-700 pt-3.5 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400">
                        Grand Total (COD)
                      </span>
                      <span className="text-lg font-black text-blue-600 dark:text-blue-400">
                        ₹{ord.totalPrice}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleUpdateOrderStatus(ord.id, 'Confirmed')}
                        className="px-3 py-2 bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-300 rounded-2xl text-xs font-extrabold cursor-pointer transition select-none"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(ord.id, 'Delivered')}
                        className="px-3 py-2 bg-green-50 hover:bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800 text-green-600 dark:text-green-300 rounded-2xl text-xs font-extrabold cursor-pointer transition select-none"
                      >
                        Deliver
                      </button>
                      <button
                        onClick={() => handleUpdateOrderStatus(ord.id, 'Cancelled')}
                        className="px-3 py-2 bg-red-50 hover:bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-300 rounded-2xl text-xs font-extrabold cursor-pointer transition select-none"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* --- SUB-VIEW 3: USERS / LOGINS LOGVIEWGER --- */}
      {activeSubTab === 'users' && (
        <div className="space-y-4 animate-fade-in">
          <h3 className="font-extrabold text-sm text-gray-800 dark:text-white pl-1">
            Registered & Logged in Customer Logins (Sheet 1)
          </h3>

          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
            {users.length === 0 ? (
              <p className="text-xs font-semibold text-gray-500">No active login logs.</p>
            ) : (
              <div className="flex flex-col gap-2">
                {users.map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center justify-between p-3 border border-gray-50 dark:border-gray-700 hover:bg-gray-50/60 dark:hover:bg-gray-800/40 rounded-2xl transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-300 flex items-center justify-center font-extrabold text-sm select-none">
                        {u.name.substring(0, 1).toUpperCase()}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-extrabold text-gray-800 dark:text-white">
                          {u.name}
                        </span>
                        <span className="text-[11px] font-semibold text-gray-400 select-none">
                          {u.phone}
                        </span>
                      </div>
                    </div>
                    <span className="text-[10px] bg-blue-50 dark:bg-blue-900/30 text-blue-600 px-2 py-0.5 rounded-full font-black border border-blue-100 dark:border-blue-900/30 select-none">
                      Active
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- SUB-VIEW 4: AREAS / SETTINGS MANAGER --- */}
      {activeSubTab === 'settings' && (
        <div className="space-y-5 animate-fade-in">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-gray-800 dark:text-white flex items-center gap-2">
              Add Regional Delivery Area (Nawada)
            </h3>

            <div className="flex gap-2">
              <input
                type="text"
                value={newArea}
                onChange={(e) => setNewArea(e.target.value)}
                placeholder="e.g. Gonawa Road, Station Road"
                className="flex-grow bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-2.5 rounded-2xl text-xs font-bold outline-none"
              />
              <button
                onClick={handleAddArea}
                className="px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-black cursor-pointer shadow-sm transition flex items-center justify-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Area
              </button>
            </div>

            <div className="pt-2">
              <label className="text-xs font-bold text-gray-500">Currently Enabled Area Dropdown List</label>
              <div className="flex flex-wrap gap-2 mt-2">
                {settings.areas.map((ar) => (
                  <div
                    key={ar}
                    className="flex items-center gap-2 bg-gray-50/50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 px-3 py-1.5 rounded-full text-xs font-bold text-gray-700 dark:text-gray-300"
                  >
                    <span>{ar}</span>
                    <button
                      onClick={() => handleRemoveArea(ar)}
                      className="text-red-500 hover:text-red-700 cursor-pointer text-sm font-black transition"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { CartItem, User, Order } from '../types';
import { Language, translations } from '../services/i18n';
import { api } from '../services/api';
import { ShoppingBag, Navigation, Smile, Coins, Trash2 } from 'lucide-react';

interface CartViewProps {
  cartItems: CartItem[];
  user: User | null;
  onUpdateQty: (pId: string, delta: number) => void;
  onRemove: (pId: string) => void;
  onClearCart: () => void;
  onContinueShopping: () => void;
  onOrderSuccess: () => void;
  lang: Language;
  areas: string[];
}

export const CartView: React.FC<CartViewProps> = ({
  cartItems,
  user,
  onUpdateQty,
  onRemove,
  onClearCart,
  onContinueShopping,
  onOrderSuccess,
  lang,
  areas,
}) => {
  const [address, setAddress] = useState(user?.address || '');
  const [selectedArea, setSelectedArea] = useState(user?.area || areas[0] || '');
  const [donation, setDonation] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showOrderPop, setShowOrderPop] = useState(false);

  const t = translations[lang];

  const subtotal = cartItems.reduce((acc, curr) => {
    const unitPrice = curr.product.discountPrice ? curr.product.discountPrice : curr.product.price;
    return acc + unitPrice * curr.quantity;
  }, 0);

  const deliveryFee = 0; // Deliveries fee free
  const total = subtotal + deliveryFee + donation;

  const handlePlaceOrder = async () => {
    if (!user) {
      alert(t.login_req);
      return;
    }
    if (cartItems.length === 0) {
      alert(t.empty_cart);
      return;
    }
    if (!address.trim()) {
      alert(lang === 'hi' ? 'कृपया अपना पता दर्ज करें।' : 'Please enter your street/landmark address.');
      return;
    }

    setIsSubmitting(true);

    const newOrder: Order = {
      id: 'ord-' + Math.random().toString(36).substring(2, 9),
      userId: user.id,
      userName: user.name,
      userPhone: user.phone,
      items: cartItems,
      totalPrice: total,
      address,
      area: selectedArea,
      donation,
      deliveryFee,
      status: 'Pending',
      date: new Date().toLocaleDateString(),
      time: new Date().toLocaleTimeString(),
    };

    // Save order in local + API
    await api.createOrder(newOrder);

    // Persist current address for returning users
    const updatedUser: User = { ...user, address, area: selectedArea };
    api.saveCurrentUser(updatedUser);

    setIsSubmitting(false);
    setShowOrderPop(true);
    onClearCart();
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 pb-20">
      <div className="flex items-center justify-between gap-3 mb-6">
        <h2 className="text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          {t.cart}
        </h2>
        {cartItems.length > 0 && (
          <button
            onClick={onContinueShopping}
            className="text-xs font-bold text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800/60 bg-blue-50/40 hover:bg-blue-50 dark:bg-blue-900/10 px-3.5 py-1.5 rounded-full cursor-pointer transition"
          >
            {lang === 'hi' ? '+ और उत्पाद जोड़ें' : '+ Add More Items'}
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700/60 shadow-sm text-center px-4">
          <div className="w-14 h-14 rounded-2xl bg-gray-50 dark:bg-gray-700 flex items-center justify-center mb-4 text-blue-500">
            <ShoppingBag className="w-6 h-6 text-blue-500" />
          </div>
          <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-4 max-w-[240px]">
            {t.empty_cart}
          </p>
          <button
            onClick={onContinueShopping}
            className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold transition duration-200 cursor-pointer shadow-md"
          >
            {lang === 'hi' ? 'खरीदारी शुरू करें' : 'Start Shopping'}
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-6">
          {/* Cart items list */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
            {cartItems.map((item) => {
              const unitPrice = item.product.discountPrice ? item.product.discountPrice : item.product.price;
              return (
                <div
                  key={item.product.id}
                  className="flex items-center justify-between border-b border-gray-50 dark:border-gray-700/60 last:border-b-0 pb-4 last:pb-0"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product.images[0] || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-2xl border border-gray-50 dark:border-gray-700 select-none flex-shrink-0"
                    />
                    <div className="flex flex-col">
                      <span className="font-bold text-sm text-gray-800 dark:text-gray-100 leading-tight mb-0.5 line-clamp-1">
                        {item.product.name}
                      </span>
                      <span className="text-[10px] text-gray-400 dark:text-gray-500 mb-1">
                        ₹{unitPrice} / {item.product.unit}
                      </span>
                      <span className="text-sm font-black text-blue-600 dark:text-blue-400">
                        ₹{unitPrice * item.quantity}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 bg-gray-50 dark:bg-gray-700/50 border border-gray-100 dark:border-gray-700 rounded-xl px-1.5 py-1">
                      <button
                        onClick={() => onUpdateQty(item.product.id, -1)}
                        className="w-6 h-6 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg flex items-center justify-center cursor-pointer transition select-none"
                      >
                        -
                      </button>
                      <span className="w-6 text-center text-xs font-black text-gray-800 dark:text-gray-100">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQty(item.product.id, 1)}
                        className="w-6 h-6 text-gray-700 dark:text-gray-300 font-bold hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg flex items-center justify-center cursor-pointer transition select-none"
                      >
                        +
                      </button>
                    </div>

                    <button
                      onClick={() => onRemove(item.product.id)}
                      className="w-8 h-8 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-900/10 dark:hover:bg-red-900/30 text-red-500 flex items-center justify-center cursor-pointer transition shadow-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* User / Address Details section */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-gray-800 dark:text-gray-100 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              {lang === 'hi' ? 'डिलीवरी विवरण' : 'Delivery Details'}
            </h3>

            {/* Locked City Display */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
                  {lang === 'hi' ? 'शहर' : 'City'}
                </label>
                <div className="mt-1 bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-700 text-gray-800 dark:text-gray-200 px-3.5 py-3 rounded-2xl text-xs font-bold select-none cursor-not-allowed">
                  Nawada
                </div>
              </div>

              {/* Dynamic Area Selector */}
              <div>
                <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
                  {lang === 'hi' ? 'क्षेत्र चुनें' : 'Select Area'}
                </label>
                <select
                  value={selectedArea}
                  onChange={(e) => setSelectedArea(e.target.value)}
                  className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-3 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
                >
                  {areas.map((ar) => (
                    <option key={ar} value={ar}>
                      {ar}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Street/landmark Address Input */}
            <div>
              <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase">
                {lang === 'hi' ? 'गली / लैंडमार्क पता' : 'Street Address / Near Landmark'}
              </label>
              <textarea
                rows={2}
                placeholder={t.street_address}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="mt-1 w-full bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-100 px-3.5 py-3 rounded-2xl text-xs font-bold select-none outline-none focus:border-blue-400"
              />
            </div>
          </div>

          {/* Optional Donations option / tip */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm space-y-3">
            <h3 className="font-extrabold text-sm text-gray-800 dark:text-gray-100 flex items-center gap-2">
              <Smile className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              {t.donation}
            </h3>
            <div className="grid grid-cols-5 gap-2">
              <button
                onClick={() => setDonation(0)}
                className={`py-2 rounded-2xl text-xs font-extrabold border transition ${
                  donation === 0
                    ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                    : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                }`}
              >
                ₹0
              </button>
              {[10, 20, 30, 40].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setDonation(amt)}
                  className={`py-2 rounded-2xl text-xs font-extrabold border transition ${
                    donation === amt
                      ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                      : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
          </div>

          {/* Pricing breakdown summary */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/60 rounded-3xl p-5 shadow-sm space-y-3.5">
            <div className="flex justify-between items-center text-xs font-bold text-gray-600 dark:text-gray-300">
              <span>{lang === 'hi' ? 'कार्ट उप-कुल (Subtotal)' : 'Cart Subtotal'}</span>
              <span>₹{subtotal}</span>
            </div>

            <div className="flex justify-between items-center text-xs font-bold text-gray-600 dark:text-gray-300">
              <span>{t.delivery_fee}</span>
              <span className="text-green-500 font-extrabold">{lang === 'hi' ? 'मुफ़्त (Free)' : 'FREE'}</span>
            </div>

            {donation > 0 && (
              <div className="flex justify-between items-center text-xs font-bold text-gray-600 dark:text-gray-300">
                <span>{lang === 'hi' ? 'दान' : 'Donation'}</span>
                <span>+ ₹{donation}</span>
              </div>
            )}

            <div className="border-t border-gray-100 dark:border-gray-700/80 pt-3 flex justify-between items-center">
              <span className="text-sm font-black text-gray-800 dark:text-white">
                {t.total}
              </span>
              <span className="text-xl font-black text-blue-600 dark:text-blue-400">
                ₹{total}
              </span>
            </div>

            {/* COD warning */}
            <div className="flex items-center gap-1.5 p-2 bg-amber-50/40 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 rounded-xl">
              <Coins className="w-4 h-4 text-amber-500 flex-shrink-0" />
              <p className="text-[10px] font-bold text-amber-700 dark:text-amber-400 leading-tight">
                {t.cash_only}
              </p>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={isSubmitting}
              className={`w-full py-4 rounded-2xl font-black transition duration-200 text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                isSubmitting
                  ? 'bg-gray-300 dark:bg-gray-700 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white hover:shadow-lg'
              }`}
            >
              {isSubmitting ? (lang === 'hi' ? 'ऑर्डर किया जा रहा है...' : 'Placing Order...') : t.place_order}
            </button>
          </div>
        </div>
      )}

      {/* Success Modal / Popup */}
      {showOrderPop && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-gray-800 rounded-3xl p-6 flex flex-col items-center text-center shadow-2xl border border-gray-100 dark:border-gray-700">
            <div className="w-16 h-16 rounded-2xl bg-green-50 dark:bg-green-900/30 text-green-500 flex items-center justify-center mb-4 text-3xl font-bold">
              ✓
            </div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white mb-2 leading-snug">
              {lang === 'hi' ? 'ऑर्डर सफल हुआ!' : 'Order Placed Successfully!'}
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-5 leading-relaxed">
              {t.order_success}
            </p>
            <button
              onClick={() => {
                setShowOrderPop(false);
                onOrderSuccess();
              }}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-2xl font-bold transition cursor-pointer text-xs"
            >
              {lang === 'hi' ? 'जारी रखें' : 'Continue'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { translations, Language } from '../services/i18n';
import { ShoppingBag, Apple, Salad, Shirt, MoreHorizontal } from 'lucide-react';

interface CategoryListProps {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  lang: Language;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  lang,
}) => {
  const t = translations[lang];

  // Map category strings to modern icons
  const getCategoryIcon = (cat: string) => {
    const lowercase = cat.toLowerCase();
    if (lowercase.includes('cloth')) return <Shirt className="w-5 h-5" />;
    if (lowercase.includes('fruit')) return <Apple className="w-5 h-5" />;
    if (lowercase.includes('veg')) return <Salad className="w-5 h-5" />;
    if (lowercase.includes('grocer')) return <ShoppingBag className="w-5 h-5" />;
    return <ShoppingBag className="w-5 h-5" />;
  };

  return (
    <div className="flex items-center gap-2 overflow-x-auto py-3 px-1 scrollbar-none">
      <button
        onClick={() => onSelectCategory('')}
        className={`flex items-center gap-1.5 px-4 py-2 rounded-full border text-xs font-bold whitespace-nowrap transition duration-200 cursor-pointer ${
          selectedCategory === ''
            ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
            : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50'
        }`}
      >
        <MoreHorizontal className="w-4 h-4" />
        {t.all}
      </button>

      {categories.map((cat) => {
        const isSelected = selectedCategory === cat;
        return (
          <button
            key={cat}
            onClick={() => onSelectCategory(cat)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border text-xs font-bold whitespace-nowrap transition duration-200 cursor-pointer ${
              isSelected
                ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-100 dark:shadow-blue-950/40'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50'
            }`}
          >
            {getCategoryIcon(cat)}
            {cat}
          </button>
        );
      })}
    </div>
  );
};

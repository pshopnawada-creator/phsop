import { useState, useEffect } from 'react';
import { api } from './services/api';
import { Language, translations } from './services/i18n';
import { Product, CartItem, Order, User, AppSettings } from './types';
import { LoginScreen } from './components/LoginScreen';
import { Navbar } from './components/Navbar';
import { CategoryList } from './components/CategoryList';
import { ProductCard } from './components/ProductCard';
import { CartView } from './components/CartView';
import { AccountView } from './components/AccountView';
import { AdminView } from './components/AdminView';
import {
  Home,
  Grid,
  ShoppingCart,
  User as UserIcon,
  ShieldCheck,
  WifiOff
} from 'lucide-react';

export default function App() {
  // Screen views state
  const [currentView, setCurrentView] = useState<'home' | 'categories' | 'cart' | 'account' | 'admin'>('home');

  // Core application states
  const [currentUser, setCurrentUser] = useState<User | null>(api.getCurrentUser());
  const [lang, setLang] = useState<Language>('en');
  const [isSkipped, setIsSkipped] = useState(false);
  const [onlineStatus, setOnlineStatus] = useState(api.isOnline());

  // Products and Category states
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');

  // Cart & orders states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(api.getOrders());
  const [users, setUsers] = useState<User[]>(api.getLogins());

  // Dynamic Settings
  const [settings, setSettings] = useState<AppSettings>({
    appName: 'pshop',
    theme: 'light',
    areas: ['Nawada Bazaar', 'Station Road', 'Old Bus Stand', 'Main Market'],
    helplinePhone: '8298799319',
    helplineEmail: 'pshopnawda@gmail.com',
  });

  // Check connection status periodically
  useEffect(() => {
    const checkStatus = () => setOnlineStatus(window.navigator.onLine);
    window.addEventListener('online', checkStatus);
    window.addEventListener('offline', checkStatus);
    return () => {
      window.removeEventListener('online', checkStatus);
      window.removeEventListener('offline', checkStatus);
    };
  }, []);

  // Sync settings and load products from Google Sheet
  useEffect(() => {
    const fetchInitialData = async () => {
      const fetchedSettings = await api.getSettings();
      setSettings(fetchedSettings);

      const fetchedProducts = await api.getProducts();
      setProducts(fetchedProducts);

      // Extract unique categories from items list
      const uniqueCats = Array.from(new Set(fetchedProducts.map((p) => p.category))).filter(Boolean);
      setCategories(uniqueCats);
    };

    fetchInitialData();
  }, []);

  // Add theme mode to HTML class attribute
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  // Handle direct Buy Now shortcut
  const handleBuyNow = (product: Product, qty: number) => {
    if (!currentUser && !isSkipped) return;
    if (isSkipped && !currentUser) {
      alert(translations[lang].login_req);
      setCurrentView('account');
      return;
    }
    const existing = cart.find((i) => i.product.id === product.id);
    if (existing) {
      setCart(
        cart.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + qty } : i
        )
      );
    } else {
      setCart([...cart, { product, quantity: qty }]);
    }
    setCurrentView('cart');
  };

  // Add item to cart
  const handleAddToCart = (product: Product, qty: number) => {
    if (!currentUser && !isSkipped) return;
    if (isSkipped && !currentUser) {
      alert(translations[lang].login_req);
      setCurrentView('account');
      return;
    }
    const existing = cart.find((i) => i.product.id === product.id);
    if (existing) {
      setCart(
        cart.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + qty } : i
        )
      );
    } else {
      setCart([...cart, { product, quantity: qty }]);
    }
  };

  // Refresh data callbacks
  const handleRefreshProducts = async () => {
    const fetched = await api.getProducts();
    setProducts(fetched);
    const uniqueCats = Array.from(new Set(fetched.map((p) => p.category))).filter(Boolean);
    setCategories(uniqueCats);
  };

  const handleRefreshOrders = () => {
    setOrders(api.getOrders());
  };

  // Update specific item quantity in cart
  const updateCartQuantity = (pId: string, delta: number) => {
    setCart(
      cart
        .map((i) => {
          if (i.product.id === pId) {
            const nextQty = i.quantity + delta;
            return nextQty > 0 ? { ...i, quantity: nextQty } : null;
          }
          return i;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const removeCartItem = (pId: string) => {
    setCart(cart.filter((i) => i.product.id !== pId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Login handler
  const handleLogin = (_name: string, _phone: string) => {
    const loggedUser = api.getCurrentUser();
    setCurrentUser(loggedUser);
    setIsSkipped(false);
    setUsers(api.getLogins());
    setCurrentView('home');
  };

  // Update profile handler
  const handleUpdateUser = (updated: User) => {
    api.saveCurrentUser(updated);
    setCurrentUser(updated);
    setUsers(api.getLogins());
  };

  // Settings update handler
  const handleUpdateSettings = async (nextSettings: AppSettings) => {
    setSettings(nextSettings);
    await api.saveSettings(nextSettings);
  };

  // Logout / clear handler
  const handleLogout = () => {
    api.clearCurrentUser();
    setCurrentUser(null);
    setIsSkipped(false);
    setCurrentView('home');
  };

  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === '' || p.category === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const t = translations[lang];

  // User hasn't logged in AND hasn't skipped -> Screen 1: Login
  if (!currentUser && !isSkipped) {
    return (
      <LoginScreen
        onLogin={handleLogin}
        onSkip={() => {
          setIsSkipped(true);
          setCurrentView('home');
        }}
        lang={lang}
        onChangeLang={setLang}
      />
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50/50 dark:bg-gray-900 transition duration-150">
      
      {/* Dynamic Connectivity Offline Warning */}
      {!onlineStatus && (
        <div className="bg-red-500 text-white text-xs font-bold py-2.5 px-4 text-center select-none flex items-center justify-center gap-2 animate-pulse z-50">
          <WifiOff className="w-4 h-4" />
          {t.no_internet}
        </div>
      )}

      {/* Modern High-Quality Top App Header */}
      <Navbar
        user={currentUser}
        lang={lang}
        onChangeLang={setLang}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onViewCart={() => setCurrentView('cart')}
        appName={settings.appName}
      />

      {/* Content Main Body Scroll view */}
      <main className="flex-grow max-w-6xl w-full mx-auto pb-20">
        
        {/* --- VIEW 1: HOME PANEL --- */}
        {currentView === 'home' && (
          <div className="px-4 py-4 animate-fade-in space-y-4">
            
            {/* Banner Promotional Carousel */}
            <div className="relative rounded-3xl bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white overflow-hidden shadow-lg shadow-indigo-100 dark:shadow-indigo-950/20 select-none flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="max-w-md">
                <span className="text-[10px] bg-white/20 text-white px-2 py-0.5 rounded-full font-extrabold tracking-wider uppercase mb-2 block self-start">
                  Flash Mega Sale
                </span>
                <h3 className="text-xl sm:text-2xl font-black leading-tight mb-1">
                  Exclusive Nawada Bazaar Collection
                </h3>
                <p className="text-xs text-blue-50 font-medium leading-relaxed">
                  Fast regional delivery to your doorstep. Browse clothing, vegetables, groceries & more.
                </p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-4xl shadow-inner font-extrabold select-none">
                🛍️
              </div>
            </div>

            {/* In-Line Category selector list */}
            <CategoryList
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              lang={lang}
            />

            {/* Detailed Products dynamic list grids */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4 select-none">
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  lang={lang}
                />
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 text-center py-10">
                {lang === 'hi' ? 'कोई उत्पाद नहीं मिला।' : 'No products match your search.'}
              </p>
            )}
          </div>
        )}

        {/* --- VIEW 2: FULL CATEGORIES FILTER --- */}
        {currentView === 'categories' && (
          <div className="px-4 py-5 animate-fade-in space-y-5">
            <div className="flex flex-col">
              <h2 className="text-lg font-extrabold text-gray-800 dark:text-white leading-tight">
                {t.category}
              </h2>
              <p className="text-xs text-gray-400 font-semibold select-none">
                Select a collection to filter active store catalog
              </p>
            </div>

            <CategoryList
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              lang={lang}
            />

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4 select-none pt-2">
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  lang={lang}
                />
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <p className="text-xs font-semibold text-gray-400 dark:text-gray-500 text-center py-10">
                {lang === 'hi' ? 'इस श्रेणी में कोई उत्पाद नहीं है।' : 'No products listed in this category.'}
              </p>
            )}
          </div>
        )}

        {/* --- VIEW 3: CART/CHECKOUT PANEL --- */}
        {currentView === 'cart' && (
          <div className="animate-fade-in">
            <CartView
              cartItems={cart}
              user={currentUser}
              onUpdateQty={updateCartQuantity}
              onRemove={removeCartItem}
              onClearCart={clearCart}
              onContinueShopping={() => setCurrentView('home')}
              onOrderSuccess={() => setCurrentView('account')}
              lang={lang}
              areas={settings.areas}
            />
          </div>
        )}

        {/* --- VIEW 4: USER ACCOUNT PROFILE PANEL --- */}
        {currentView === 'account' && (
          <div className="animate-fade-in">
            <AccountView
              user={currentUser}
              onUpdateUser={handleUpdateUser}
              onLogout={handleLogout}
              lang={lang}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              areas={settings.areas}
            />
          </div>
        )}

        {/* --- VIEW 5: SPECIAL VENDOR / PORTAL CONTROL --- */}
        {currentView === 'admin' && (
          <div className="animate-fade-in">
            <AdminView
              products={products}
              orders={orders}
              users={users}
              settings={settings}
              onRefreshProducts={handleRefreshProducts}
              onRefreshOrders={handleRefreshOrders}
              onUpdateSettings={handleUpdateSettings}
              lang={lang}
            />
          </div>
        )}
      </main>

      {/* --- CLASSIC BOTTOM TOOLBAR / ICON NAVIGATION --- */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700/80 shadow-lg px-2 select-none">
        <div className="max-w-md mx-auto h-16 flex items-center justify-around">
          <button
            onClick={() => setCurrentView('home')}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl gap-0.5 cursor-pointer transition duration-150 ${
              currentView === 'home'
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30'
                : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-black">{t.home}</span>
          </button>

          <button
            onClick={() => setCurrentView('categories')}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl gap-0.5 cursor-pointer transition duration-150 ${
              currentView === 'categories'
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30'
                : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
            }`}
          >
            <Grid className="w-5 h-5" />
            <span className="text-[10px] font-black">{t.category}</span>
          </button>

          <button
            onClick={() => setCurrentView('cart')}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl gap-0.5 cursor-pointer transition duration-150 relative ${
              currentView === 'cart'
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30'
                : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
            }`}
          >
            <ShoppingCart className="w-5 h-5" />
            <span className="text-[10px] font-black">{t.cart}</span>
            {cart.length > 0 && (
              <span className="absolute top-0 right-1 w-2 h-2 bg-red-500 rounded-full ring-1 ring-white dark:ring-gray-800"></span>
            )}
          </button>

          <button
            onClick={() => setCurrentView('account')}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl gap-0.5 cursor-pointer transition duration-150 ${
              currentView === 'account'
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30'
                : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
            }`}
          >
            <UserIcon className="w-5 h-5" />
            <span className="text-[10px] font-black">{t.account}</span>
          </button>

          {/* Exclusive Merchant Tool tab to test Google Sheets dynamic edit/change functionality */}
          <button
            onClick={() => setCurrentView('admin')}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-2xl gap-0.5 cursor-pointer transition duration-150 ${
              currentView === 'admin'
                ? 'text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/30'
                : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
            }`}
          >
            <ShieldCheck className="w-5 h-5" />
            <span className="text-[10px] font-black">Admin</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
